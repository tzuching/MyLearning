#!/bin/bash

###
# 請先記得修改版號（編輯 6 個 deploy_xxxxx.yaml）
# 路徑為 image: asia.gcr.io/asia-mail-awoo-org/edm-core:v1.0.4 -> 記得修改掉版號

###
echo "##### 版本更新作業 #####"
sleep 1
read -p "Continue ? [請再次確認是否要繼續執行] ( 1 = 繼續 or 0 = 離開 ) : " GO_CONTINUE
sleep 1
if [ $GO_CONTINUE -eq 0 ]; then
    echo "Bye! Bye!"
    exit
else
    echo "Go! Continue!"
fi

###
gcloud container clusters get-credentials awoo-gke-mail-service --zone asia-east1-b --project asia-mail-awoo-org
sleep 1

###
kubectl -n mail-schedule get pod
sleep 1

###
kubectl -n mail-schedule apply -f deploy_gmail.yaml
kubectl -n mail-schedule apply -f deploy_hinet.yaml
kubectl -n mail-schedule apply -f deploy_hotmail.yaml
kubectl -n mail-schedule apply -f deploy_other.yaml
kubectl -n mail-schedule apply -f deploy_qq.yaml
kubectl -n mail-schedule apply -f deploy_yahoo.yaml
sleep 3

###
kubectl -n mail-schedule get nodes,pods,svc,deploy,cm,ns -o wide
sleep 1

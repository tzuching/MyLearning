#!/bin/bash

### 手動輸入版號
_OLD_="1.0.6";
_NEW_="1.0.7";

###
echo "##### 版本更新作業_變更版號 #####"
sleep 1
read -p "Continue ? [請再次確認是否要繼續執行] ( 1 = 繼續 or 0 = 離開 ) : " GO_CONTINUE
sleep 1
if [ $GO_CONTINUE -eq 0 ]; then
    echo "Bye! Bye!"
    exit
else
    echo "Go! Continue!"
fi

###
gcloud container clusters get-credentials awoo-gke-mail-service --zone asia-east1-b --project asia-mail-awoo-org
sleep 1

###
kubectl -n mail-schedule get pod
sleep 1

###
sed -i "s/v${_OLD_}/v${_NEW_}/g" deploy_gmail.yaml
sed -i "s/v${_OLD_}/v${_NEW_}/g" deploy_hinet.yaml
sed -i "s/v${_OLD_}/v${_NEW_}/g" deploy_hotmail.yaml
sed -i "s/v${_OLD_}/v${_NEW_}/g" deploy_other.yaml
sed -i "s/v${_OLD_}/v${_NEW_}/g" deploy_qq.yaml
sed -i "s/v${_OLD_}/v${_NEW_}/g" deploy_yahoo.yaml

###

#!/bin/bash

###
# 請先記得修改版號（編輯 6 個 deploy_xxxxx.yaml）
# 路徑為 image: asia.gcr.io/asia-mail-awoo-org/edm-core:v1.0.4 -> 記得修改掉版號

###
echo "##### Scale 成 0 台作業 #####"
sleep 1
read -p "Continue ? [請再次確認是否要繼續執行] ( 1 = 繼續 or 0 = 離開 ) : " GO_CONTINUE
sleep 1
if [ $GO_CONTINUE -eq 0 ]; then
    echo "Bye! Bye!"
    exit
else
    echo "Go! Continue!"
fi

###
gcloud container clusters get-credentials awoo-gke-mail-service --zone asia-east1-b --project asia-mail-awoo-org
sleep 1

###
kubectl -n mail-schedule get pod
sleep 1

###
kubectl -n mail-schedule --replicas=0 scale deploy gmail
kubectl -n mail-schedule --replicas=0 scale deploy hinet
kubectl -n mail-schedule --replicas=0 scale deploy hotmail
kubectl -n mail-schedule --replicas=0 scale deploy other
kubectl -n mail-schedule --replicas=0 scale deploy qq
kubectl -n mail-schedule --replicas=0 scale deploy yahoo
###

# 刪除指令
# kubectl -n mail-schedule delete deployment edm-core-qq
###

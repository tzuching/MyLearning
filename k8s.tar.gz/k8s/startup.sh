#!/bin/bash
echo Will start server using: ISP=${ISP} SWOOLE_PORT=${SWOOLE_PORT} ENV=${ENV}
php /var/www/html/app_local/sch.tigerflyapp.tw/edm-core/launcher.php ${ISP} ${SWOOLE_PORT} ${ENV}

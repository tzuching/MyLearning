#!/bin/bash
. "/home/daniel/script/system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${DBMONITOR_PATH}/_srvList.${1}.sh"

LOG="${LOG_PATH}/chkRedisInfo.${1}.${NDATE}.log";
PROCESS_FILE="/tmp/chkRedisInfo.pid";
REDIS="/usr/bin/redis-cli";
DBPASS="MawooSDvo5rtjqPnJtp7rKyredisxZ";

### Check Process
_chkProcess "${PROCESS_FILE}";

### Return this script pid
echo $$ > ${PROCESS_FILE}

# redis-cli -h 172.16.0.3 -p 6379 -a 'MawooSDvo5rtjqPnJtp7rKyredisxZ'

for dbportIdx in "${!DBPORT[@]}"
do
  dbip=${DBIP[$dbportIdx]};
  dbhost=${DBHOST[$dbportIdx]};
  dbport=${DBPORT[$dbportIdx]};
  dblimit=${DBLIMIT[$dbportIdx]};
  dbswap=${DBSWAP[$dbportIdx]};
  dbcount=${DBCOUNT[$dbportIdx]};

    echo "[ ${NDATETIME} ] ${dbhost} (${dbip})" >> ${LOG};
    ${REDIS} -h ${dbip} -p ${dbport} -a ${DBPASS} INFO >> ${LOG};
    echo "-------------------------------------------------------" >> ${LOG};
done
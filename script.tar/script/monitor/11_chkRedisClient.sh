#!/bin/bash
. "/home/daniel/script/system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${DBMONITOR_PATH}/_srvList.${1}.sh"

LOG="${LOG_PATH}/chkRedisClient.${1}.${NDATE}.log";
ERROR_LOG="${LOG_PATH}/error_chkRedisClient.${1}.${NDATE}.log";
CLIENT_LOG="${LOG_PATH}/chkRedisClient_info.${1}.${NDATE}.log";
PROCESS_FILE="/tmp/chkRedisClient.pid";
REDIS="/usr/bin/redis-cli";
DBPASS="MawooSDvo5rtjqPnJtp7rKyredisxZ";

### Check Process
_chkProcess "${PROCESS_FILE}";

### Return this script pid
echo $$ > ${PROCESS_FILE}

# redis-cli -h 172.16.0.3 -p 6379 -a 'MawooSDvo5rtjqPnJtp7rKyredisxZ'

for dbportIdx in "${!DBPORT[@]}"
do
  dbip=${DBIP[$dbportIdx]};
  dbhost=${DBHOST[$dbportIdx]};
  dbport=${DBPORT[$dbportIdx]};
  dblimit=${DBLIMIT[$dbportIdx]};
  dbswap=${DBSWAP[$dbportIdx]};
  dbcount=${DBCOUNT[$dbportIdx]};

    echo "[ ${NDATETIME} ] ${dbhost} (${dbip})" >> ${CLIENT_LOG};
    ${REDIS} -h ${dbip} -p ${dbport} -a ${DBPASS} CLIENT LIST >> ${CLIENT_LOG};
    echo "--------------------------------------------------------------------------------------------------------------" >> ${CLIENT_LOG};

  if [ $NHOUR -gt "08" ] && [ $NHOUR -lt "18" ] ; then

     declare -i nowcount=`${REDIS} -h ${dbip} -p ${dbport} -a ${DBPASS} CLIENT LIST |wc -l`;
     echo "[ Redis ] [ ${NDATETIME} ] ${dbhost} -> Redis Client Count Is ${nowcount}." >> ${LOG};

     if [ "$nowcount" -gt "${dbcount}" ]; then
        echo "[ Redis ] [ ${NDATETIME} ] ${dbhost} -> Redis Client Count Is ${nowcount} Over ${dbcount}." >> ${ERROR_LOG};
        nowerrmsg="[ Redis ] [ ${NDATETIME} ] ${dbhost} -> Redis Client Count Is ${nowcount} Over ${dbcount}";
        #printf "To: ${DBA_MAIL}\nFrom: ${DBA_MAIL}\nSubject: ${nowerrmsg}\n\nCritical Message\n" | /usr/sbin/ssmtp -t
        _sendErrorMESSAGE_slack "${dbhost}_Redis_Client_Count_Is_${nowcount}_Over_${dbcount}_!";
     fi
  fi
done
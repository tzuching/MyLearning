#!/bin/bash
. "/home/daniel/script/system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${DBMONITOR_PATH}/_srvList.${1}.sh"

LOG="${LOG_PATH}/chkProcesslist.${1}.${NDATE}.log";
ERROR_LOG="${LOG_PATH}/error_chkProcesslist.${1}.${NDATE}.log";
PROCESS_FILE="/tmp/chkProcesslist.pid";
DBUSER="dba_monitor";
DBPASSWD="D7EZvvcck3te6qH4MqhCam25DdaXDbMB";
DBHOSTIP="104.155.234.224";
DBHOSTNAME="Poseidon_Mysql";
QUERYLIMIT="3";

# ====================================================================================================

#CHECK_LIST=`mysql -u${DBUSER} -p${DBPASSWD} -e "SELECT TIME FROM INFORMATION_SCHEMA.PROCESSLIST"| wc -l | awk 'NR==2{printf $1}'`;
#SQL_1="INSERT INTO processlist (DAY,TIME,HOST,LIST)";
#SQL_2="${SQL_1} VALUES ('"${MYSQLDAY}"','"${MYSQLTIME}"','"${HOST}"',${CHECK_LIST});";
#INSSQL="/tmp/processlist_insert.${FILETIME}.sql";
#/usr/bin/echo ${MYSQLDB}${SQL_2} >> ${INSSQL}
#/usr/bin/scp -r ${INSSQL} ${SSHUSER}@${SSHIP}://tmp
#${SSHOPTION} ${SSHUSER}@${SSHIP} "${MYSQLCMD} -v -u${MYSQLUSER} -p${MYSQLPASS} < ${INSSQL}";
#${SSHOPTION} ${SSHUSER}@${SSHIP} "rm -rf ${INSSQL}";${SSHOPTION} ${SSHUSER}@${SSHIP} "rm -rf ${INSSQL}";
#/usr/bin/rm -rf ${INSSQL}

# ====================================================================================================

### Check Process
_chkProcess "${PROCESS_FILE}";

### Return this script pid
echo $$ > ${PROCESS_FILE}

for dbiplidx in "${!DBIP[@]}"
do
  dbip=${DBIP[$dbiplidx]};
  dbhost=${DBHOST[$dbiplidx]};

  if [ ${NHOUR} -ge "08" ] && [ ${NHOUR} -lt "20" ] ; then

      PROCESSLIST_CHECK=`mysql -u${DBUSER} -p${DBPASSWD} -h${DBHOSTIP} -e "SELECT TIME FROM INFORMATION_SCHEMA.PROCESSLIST WHERE COMMAND = 'Query' AND TIME > 1800 ORDER BY TIME DESC LIMIT 1"| awk 'NR==2{printf $1}'`;

     if [[ -z "${PROCESSLIST_CHECK}" ]]; then
                echo -e "[ ${NDATETIME} ] ${dbhost} (${DBHOSTNAME}) SQL Query Is Good." >> ${LOG};
        else

         if [ "${PROCESSLIST_CHECK}" -gt "${QUERYLIMIT}" ]; then
                echo -e "[ ${NDATETIME} ] ${dbhost} (${DBHOSTNAME}) SQL Query Is ${PROCESSLIST_CHECK} Sec !" >> ${ERROR_LOG};
                nowerrmsg="[ ${NDATETIME} ] ${dbhost} (${DBHOSTNAME}) SQL Query Is ${PROCESSLIST_CHECK} Sec.";
                #printf "To: ${DBA_MAIL}\nFrom: ${DBA_MAIL}\nSubject: ${nowerrmsg}\n\nCritical Message\n" | /usr/sbin/ssmtp -t
                _sendErrorMESSAGE_slack "${DBHOSTNAME}_SQL_Query_Is_${PROCESSLIST_CHECK}_Sec_!";
         fi
     fi
  fi
done
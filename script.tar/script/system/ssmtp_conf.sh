### ****************************************************************************************************

# 安裝與設定 SSMTP

sudo yum install ssmtp mutt mailutils dos2unix

# 接著要設定 SSMTP 的設定檔，更改之前先將預設的 SSMTP 設定檔備份起來：

sudo cp /etc/ssmtp/ssmtp.conf /etc/ssmtp/ssmtp.conf.default

#####

# 權限
sudo chown -R daniel:daniel /usr/sbin/ssmtp
sudo chown -R daniel:daniel /etc/ssmtp/

vim /etc/ssmtp/ssmtp.conf

#####
root=awoo.monitor@gmail.com

# The place where the mail goes. The actual machine name is required
# no MX records are consulted. Commonly mailhosts are named mail.domain.com
# The example will fit if you are in domain.com and your mailhub is so named.
#mailhub=mail
mailhub=smtp.gmail.com:587

# Example for SMTP port number 2525
# mailhub=mail.your.domain:2525
# Example for SMTP port number 25 (Standard/RFC)
# mailhub=mail.your.domain
# Example for SSL encrypted connection
# mailhub=mail.your.domain:465

AuthUser=awoo.monitor@gmail.com
AuthPass=awoo9monitor9AWOO

# Where will the mail seem to come from?
#RewriteDomain=

# The full hostname
#Hostname=
Hostname=Earth

# Set this to never rewrite the "From:" line (unless not given) and to
# use that address in the "from line" of the envelope.
FromLineOverride=YES

# Use SSL/TLS to send secure messages to server.
UseTLS=YES
#IMPORTANT: The following line is mandatory for TLS authentication
TLS_CA_File=/etc/pki/tls/certs/ca-bundle.crt

# Use SSL/TLS certificate to authenticate against smtp host.
UseSTARTTLS=YES

# Use this RSA certificate.
#TLSCert=/etc/pki/tls/private/ssmtp.pem

# Get enhanced (*really* enhanced) debugging information in the logs
# If you want to have debugging of the config file parsing, move this option
# to the top of the config file and uncomment
Debug=YES
#####

### ****************************************************************************************************

### 編輯mutt的總設置，修改以下幾行

sudo vim /etc/Muttrc

set from="awoo.monitor@gmail.com"
set sendmail="/usr/sbin/ssmtp"
set use_from=yes
set realname="awoo.monitor"
set editor="vi"

### 發送附加檔案的 mail 指令
echo "2017-06-29_Monitoring-Reports" | mutt -s "2017-06-29_Monitoring-Reports" -a /home/daniel/monitor/00_log/chkCpu.earth.20170629.log -- daniel@awoo.com.tw

### ****************************************************************************************************

# ================================================================================ #

### Check Server
*/1 * * * * /home/daniel/script/03_mysql/01_chkLive.sh awooci > /dev/null 2>&1
*/1 * * * * /home/daniel/script/03_mysql/02_chkOSIP.sh awooci > /dev/null 2>&1
*/1 * * * * /home/daniel/script/03_mysql/03_chkCpu.sh awooci > /dev/null 2>&1
0 */1 * * * /home/daniel/script/03_mysql/04_chkSpace.sh awooci > /dev/null 2>&1
0 */1 * * * /home/daniel/script/03_mysql/05_chkSwap.sh awooci > /dev/null 2>&1
*/1 * * * * /home/daniel/script/03_mysql/06_chkIO_read.sh awooci > /dev/null 2>&1
*/1 * * * * /home/daniel/script/03_mysql/07_chkIO_wrtn.sh awooci > /dev/null 2>&1

### Monitoring Reports
0 10,13,18 * * * /home/daniel/script/01_system/monitoring-reports.sh awooci > /dev/null 2>&1

# ================================================================================ #

### ****************************************************************************************************
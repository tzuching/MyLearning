#!/bin/bash
#============================================================
### Host Nmae
HOST=`hostname -s`;
#============================================================
### Admin Mail
DBA_MAIL="daniel@awoo.com.tw";
#============================================================
### Set Time
NMINS=`date +"%M"`;
NHOUR=`date +"%H"`;
NDATE=`date +"%Y%m%d"`;
NDATETIME=`date +"%Y-%m-%d %H:%M:%S"`;
#============================================================
### File Path
LOG_PATH="/home/daniel/script/log";
INCLUDE_PATH="/home/daniel/script/system";
DBMONITOR_PATH="/home/daniel/script/monitor";
SLACK_LOG="${LOG_PATH}/message.slack.${NDATE}.log";
touch ${SLACK_LOG}
chmod 700 ${SLACK_LOG}
#============================================================
### Delete old log
find ${LOG_PATH}/*.log -mtime +90 -exec rm -rf {} \;
find ${LOG_PATH}/*.log -empty -exec rm -rf {} \;
cat /dev/null > /home/daniel/sent
#============================================================
### Mongodb Error
ERRGREP1[0]="[rsHealthPoll]";
ERRGREP2[0]="down|heartbeat failed|pthread_create failed";
#ERRGREP2[0]="conn125";
#ERRGREP1[1]="[WriteBackListener";
#ERRGREP2[1]="9001 socket exception|110 Connection timed out";
#============================================================
### Use Mysql
SSHOPTION="ssh -o StrictHostKeyChecking=no -o ConnectTimeout=1";
SSHUSER="daniel";
SSHIP="35.194.235.112";
MYSQLCMD="/usr/bin/mysql";
MYSQLUSER="dba_monitor";
MYSQLPASS="'awood049mon2l4itorejo39AWOO'";
MYSQLDB="use awoo_monitor;";
MYSQLDAY=`date +"%Y-%m-%d"`;
MYSQLTIME=`date +"%H:%M"`;
FILETIME=`date +"%Y%m%d%H%M"`;
#============================================================
#!/bin/bash
. "/home/daniel/script/system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${DBMONITOR_PATH}/_srvList.${1}.sh"

LOG="${LOG_PATH}/monitoring.reports.${1}.${NDATE}.log";
PROCESS_FILE="/tmp/reports.pid";
REPORTS="Monitoring-Reports";
MUTT="/usr/bin/mutt";
DAYDATE=`date +"%Y-%m-%d %H:%M"`;

### Check Process
_chkProcess "${PROCESS_FILE}";

### return this script pid
echo $$ > ${PROCESS_FILE}

# ==================================================

### Log Path
LIVE="-a ${LOG_PATH}/chkLive.${1}.${NDATE}.log";
OSIP="-a ${LOG_PATH}/chkOSIP.${1}.${NDATE}.log";
CPU="-a ${LOG_PATH}/chkCpu.${1}.${NDATE}.log";
SPACE="-a ${LOG_PATH}/chkSpace.${1}.${NDATE}.log";
SWAP="-a ${LOG_PATH}/chkSwap.${1}.${NDATE}.log";
RIO="-a ${LOG_PATH}/chkIO.read.${1}.${NDATE}.log";
WIO="-a ${LOG_PATH}/chkIO.wrtn.${1}.${NDATE}.log";

# ==================================================

### Mail Reports
echo "${DAYDATE}_${REPORTS}" | ${MUTT} -s "${DAYDATE}_${REPORTS}_${1}" ${LIVE} ${OSIP} ${CPU} ${SPACE} ${SWAP} ${RIO} ${WIO} -- ${DBA_MAIL}

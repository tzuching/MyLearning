##################################################
# Script Name :  System shell
# Maintainer  :  Daniel Tsai
# Updated     :  2017-06
##################################################
#!/bin/bash
#####
echo " "
echo "執行 [ 1. yum ] [ 2. set SWAP ] [ 3. set Folder ] ( #如輸入錯誤請按 Ctrl + C 即可離開 )"
echo " "
##########
read -p "Continue ? [請再次確認是否要繼續執行] ( 1 = 繼續 or 0 = 離開 ) : " GO_CONTINUE
### Continue
sleep 1
if [ $GO_CONTINUE -eq 0 ]; then
    echo " "
    echo "Bye! Bye!"
    echo " "
    exit
else
    echo " "
    echo "Go! Continue!"
    echo " "
fi
##########
echo " "
echo "您選擇繼續執行 - [ 開始變更系統環境 ] !"
echo " "
##################################################
### yum update
sleep 1
#sudo yum update -y
### yum install
sleep 1
sudo yum install -y dstat htop nc numactl tree socat tmux sysbench telnet curl ssmtp mutt mailutils netstat wget sysstat
##########
### SELINUX
sleep 1
#setenforce 0
#sed -i 's/SELINUX=enforcing/SELINUX=permissive/g' /etc/sysconfig/selinux
cat /etc/sysconfig/selinux | grep SELINUX
### Group Add
sleep 1
sudo groupadd dba
##########
echo " "
echo "1. 系統 yum 更新完成 !"
echo " "
##################################################
### dd SWAP
#sleep 2
#sudo dd if=/dev/zero of=/swapfile bs=1024 count=2097152
### mk
#sleep 2
#sudo mkswap /swapfile
### on
#sleep 2
#sudo swapon /swapfile
### in fstab
#echo " "
#echo "/swapfile               swap                    swap    defaults        0 0" >> /etc/fstab
#echo " "
### cat file
#cat /etc/fstab
### chown
#sudo chown root:root /swapfile
#sudo chmod 0600 /swapfile
### swappiness
#sleep 1
#sudo sysctl vm.swappiness=10
### sysctl.conf
echo " " >> /etc/sysctl.conf
echo "vm.swappiness = 10" >> /etc/sysctl.conf
##########
SWAP_SIZE=$(free -m |grep Swap)
echo " "
echo "2. SWAP [ /swapfile ] --- ( $SWAP_SIZE ) 完成"
echo " "
##################################################
### set folder
sleep 1
mkdir -p /awoo
chown -R root:dba /awoo
chmod -R o-rwx /awoo
chmod -R ug+rwx /awoo
### sleep
sleep 1
mkdir /data
mkdir /data/backup
mkdir /data/log
### sleep
sleep 1
chown -R root:dba /data
chown -R root:dba /data/backup
chmod -R o-rwx /data/backup
chmod -R ug+rwx /data/backup
chown -R root:dba /data/log
chmod -R o-rwx /data/log
chmod -R ug+rwx /data/log
sleep 1
##########
echo " "
echo "3. 新增 [ awoo及相關資料夾 ] 完成 !"
echo " "
##################################################
read -p "* 請選擇要安裝的資料庫系統或是離開 [請再次確認是否要繼續執行] ( 3 = MongoDB_Percona 版 or 2 = MariaDB or 1 = Redis or 0 = 離開 ) : " GO_DB_INSTALL
### Continue
if [ $GO_DB_INSTALL = "3" ]
then
    echo "您選擇安裝 [ MongoDB_Percona 版 ]"
				##################################################
				sleep 1
				### [ for mongodb ] add user
				useradd -g dba -m -s /bin/bash mongodb
				##################################################
				## Centos 7 - vim /etc/rc.d/rc.local
				sleep 1				
				sudo chmod +x /etc/rc.d/rc.local
				echo "sudo /bin/systemctl stop mongod.service">> /etc/rc.d/rc.local
				##################################################				
				### [ for mongodb ]  limits
				sleep 1		
				echo " ">> /etc/security/limits.conf
				echo "mongodb soft stack     20480">> /etc/security/limits.conf
				echo "mongodb hard stack     20480">> /etc/security/limits.conf
				cat /etc/security/limits.conf
				##################################################
				### WARNING /sys/kernel/mm/transparent_hugepage/enabled is 'always'.
				sleep 1
				echo "echo never > /sys/kernel/mm/transparent_hugepage/enabled">> /etc/rc.d/rc.local
				echo "echo never > /sys/kernel/mm/transparent_hugepage/defrag">> /etc/rc.d/rc.local
				sleep 1
				echo never > /sys/kernel/mm/transparent_hugepage/enabled
				echo never > /sys/kernel/mm/transparent_hugepage/defrag
				sleep 1
				cat /sys/kernel/mm/transparent_hugepage/enabled
				cat /sys/kernel/mm/transparent_hugepage/defrag
				##################################################
				### [ for mongodb ] install
				sleep 1
				sudo yum install -y http://www.percona.com/downloads/percona-release/redhat/0.1-4/percona-release-0.1-4.noarch.rpm
				sleep 2				
				sudo yum list | grep Percona-Server-MongoDB-34
				sleep 1				
				sudo yum install -y Percona-Server-MongoDB-34
				##################################################				
				## Centos 7 - stop mongod.service
				sudo /bin/systemctl stop mongod.service
				sudo /bin/systemctl disable mongod.service				
				##################################################				
				### check info
				/usr/bin/mongo --version
				##################################################
elif [ $GO_DB_INSTALL = "2" ]
then
    echo "您選擇安裝 [ MariaDB ]"
				##################################################	
				sleep 1
				### [ for mariadb ] install
				touch /etc/yum.repos.d/mariadb.repo
				sleep 2
				### [ for 64-bit installs of CentOS, add the following lines. ]
				echo "# MariaDB 10.2.06 Stable (GA) - created 2017-05-23" >> /etc/yum.repos.d/mariadb.repo
				echo "# MariaDB 10.1.23 Stable (GA) - created 2017-05-03" >> /etc/yum.repos.d/mariadb.repo
				echo "# http://mariadb.org/mariadb/repositories/" >> /etc/yum.repos.d/mariadb.repo
				echo "[mariadb]" >> /etc/yum.repos.d/mariadb.repo
				echo "name=MariaDB" >> /etc/yum.repos.d/mariadb.repo
				echo "baseurl=http://yum.mariadb.org/10.1/centos6-amd64" >> /etc/yum.repos.d/mariadb.repo
				echo "gpgkey=https://yum.mariadb.org/RPM-GPG-KEY-MariaDB" >> /etc/yum.repos.d/mariadb.repo
				echo "gpgcheck=1" >> /etc/yum.repos.d/mariadb.repo
				sleep 1
				cat /etc/yum.repos.d/mariadb.repo
				sleep 3
				sudo yum install -y MariaDB-server MariaDB-client rsync galera MariaDB-devel*
				### check info
				yum info MariaDB-server
				##################################################
    exit 0
				##################################################
elif [ $GO_DB_INSTALL = "1" ]
then
    echo "您選擇安裝 [ Redis ]"
				##################################################	
				sleep 1
				### [ for redis ] install
				cd /awoo
				#wget http://download.redis.io/releases/redis-4.0.1.tar.gz
				#wget http://download.redis.io/releases/redis-3.2.10.tar.gz
				#sudo yum install -y jemalloc tcl-devel tk-devel gcc
				sudo yum install -y redis
				sleep 2
				### [ for 64-bit installs of CentOS, add the following lines. ]		
				echo " ">> /etc/sysctl.conf
				echo "vm.overcommit_memory = 1">> /etc/sysctl.conf
				echo "net.core.somaxconn=20480">> /etc/sysctl.conf
				echo "#">> /etc/sysctl.conf
				cat /etc/sysctl.conf
				sysctl -p
				sleep 1
				cat /etc/sysctl.conf
				sleep 3
				mkdir -p /data/redis
				### check info
				yum info Redis
				##################################################
    exit 0	
##########	
elif [ $GO_DB_INSTALL = "0" ]
then
    echo "您選擇 [ 離開安裝 ]"
    exit 0
else
    echo "Please try again from given options only."
fi
##########				
echo " "
echo "執行完畢 [ End ]"
echo " "
##################################################
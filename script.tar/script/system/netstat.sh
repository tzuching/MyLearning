#!/bin/bash
netstat -na
echo "顯示port80連線並排序"
netstat -an | grep :80 | sort
echo "列出主機上有多少個 SYNC_REC"
netstat -n -p|grep SYN_REC | wc -l
echo "列出 SYNC_REC，但不只列出數字，而是將每個 SYNC_REC 的連線列出"
netstat -n -p | grep SYN_REC | sort -u
echo "列出發送 SYNC_REC 的所有 ip 地址"
netstat -n -p | grep SYN_REC | awk '{print $5}' | awk -F: '{print $1}'
echo "計算每個ip在主機上建立的連線數量"
netstat -ntu | awk '{print $5}' | cut -d: -f1 | sort | uniq -c | sort -n
echo "列出從TCP或UDP連線到主機的 ip 數量"
netstat -anp |grep 'tcp|udp' | awk '{print $5}' | cut -d: -f1 | sort | uniq -c | sort -n
echo "列出每個 ip 建立的ESTABLISHED 連線數量"
netstat -ntu | grep ESTAB | awk '{print $5}' | cut -d: -f1 | sort | uniq -c | sort -nr
echo "列出每個 ip 建立的port80 連線數量"
netstat -plan|grep :80|awk {'print $5'}|cut -d: -f 1|sort|uniq -c|sort -nk 1
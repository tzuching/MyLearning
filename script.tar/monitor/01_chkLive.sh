#!/bin/bash
. "/home/daniel/script/system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${DBMONITOR_PATH}/_srvList.${1}.sh"

LOG="${LOG_PATH}/chkLive.${1}.${NDATE}.log";
ERROR_LOG="${LOG_PATH}/error_chkLive.${1}.${NDATE}.log";
PROCESS_FILE="/tmp/chkLive.pid";

### Check Process
_chkProcess "${PROCESS_FILE}";

### return this script pid
echo $$ > ${PROCESS_FILE}

for dbportIdx in "${!DBPORT[@]}"
do
  declare -i failCount=0;
  dbip=${DBIP[$dbportIdx]};
  dbhost=${DBHOST[$dbportIdx]};
  dbport=${DBPORT[$dbportIdx]};

  for (( i=1; i<=5; i=i+1 ))
  do
    NTIME=`date +"%Y-%m-%d %H:%M:%S"`;  
    declare portStatus=`netstat -nlt|grep -c "${dbport}"`;
    echo -e "${NTIME} Connection To ${dbhost} (${dbip}) ${dbport} Port [tcp/*] ( status ${portStatus} )" >> ${LOG};

    if [ ${portStatus} -eq "0" ] ; then
       failCount=failCount+1;
    fi
    sleep 3;
  done

  if [ ${failCount} -eq "5" ] ; then
    echo -e "${NTIME} Connection To ${dbhost} (${dbip}) Port ${dbport} is FAIL !" >> ${ERROR_LOG};
    nowerrmsg="[ ${NTIME} ] Connection To ${dbhost} (${dbip}) Port ${dbport} is FAIL";
    #printf "To: ${DBA_MAIL}\nFrom: ${DBA_MAIL}\nSubject: ${nowerrmsg}\n\nCritical Message\n" | /usr/sbin/ssmtp -t
    _sendErrorMESSAGE_slack "${dbhost}_Port_${dbport}_is_FAIL_!";    
  fi
done
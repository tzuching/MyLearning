#!/bin/bash
. "/home/daniel/script/system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${DBMONITOR_PATH}/_srvList.${1}.sh"

PROCESS_FILE="/tmp/_monitor_one.pid";
FAIL=0;

### Check Process
_chkProcess "${PROCESS_FILE}";

### Return this script pid
echo $$ > ${PROCESS_FILE}

### Check Server Script
sleep 1 && /usr/bin/sudo /home/daniel/script/monitor/04_chkSpace.sh houstonapp > /dev/null 2>&1 && true &
sleep 1 && /usr/bin/sudo /home/daniel/script/monitor/05_chkSwap.sh houstonapp > /dev/null 2>&1 && true &

### Wait
for job in `jobs -p`
do
  echo "Wait job: ${job}"
  wait $job || let FAIL+=1
done

### Check
if [ $FAIL -eq 0 ]; then
  echo "All jobs are done."
else
  echo "${FAIL} jobs fail!"
fi

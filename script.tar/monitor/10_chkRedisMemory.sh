#!/bin/bash
. "/home/daniel/script/system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${DBMONITOR_PATH}/_srvList.${1}.sh"

LOG="${LOG_PATH}/chkRedisMemory.${1}.${NDATE}.log";
ERROR_LOG="${LOG_PATH}/error_chkRedisMemory.${1}.${NDATE}.log";
PROCESS_FILE="/tmp/chkRedisMemory.pid";
REDIS="/usr/bin/redis-cli";
DBPASS="MawooSDvo5rtjqPnJtp7rKyredisxZ";

### Check Process
_chkProcess "${PROCESS_FILE}";

### Return this script pid
echo $$ > ${PROCESS_FILE}

# VSLIMIT[0]="9824627200";   # VSCOUNT[0]="1000";
# redis-cli -h 172.16.0.3 -p 6379 -a 'MawooSDvo5rtjqPnJtp7rKyredisxZ'

for dbportIdx in "${!DBPORT[@]}"
do
  dbip=${DBIP[$dbportIdx]};
  dbhost=${DBHOST[$dbportIdx]};
  dbport=${DBPORT[$dbportIdx]};
  dblimit=${DBLIMIT[$dbportIdx]};
  dbswap=${DBSWAP[$dbportIdx]};

  declare -i mem_usage=`${REDIS} -h ${dbip} -p ${dbport} -a ${DBPASS} info | grep "used_memory:" |xargs -i expr substr {} 13 13 | tr -d "\r"`
  echo "[ Redis ] [ ${NDATETIME} ] ${dbhost} -> Used Redis Memory Is ${mem_usage}." >> ${LOG};

  if [ "$mem_usage" -gt "${dblimit}" ]; then
    echo "[ Redis ] [ ${NDATETIME} ] ${dbhost} -> Used Redis Memory ${mem_usage} Over 50 per." >> ${ERROR_LOG};
    nowerrmsg="[ Redis ] [ ${NDATETIME} ] ${dbhost} -> Used Redis Memory ${mem_usage} Over 50 per";
    #printf "To: ${DBA_MAIL}\nFrom: ${DBA_MAIL}\nSubject: ${nowerrmsg}\n\nCritical Message\n" | /usr/sbin/ssmtp -t
    _sendErrorMESSAGE_slack "${dbhost}_Used_Redis_Memory_${mem_usage}_Over_50_per_!";
  fi
done
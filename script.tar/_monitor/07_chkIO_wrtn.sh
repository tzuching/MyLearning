#!/bin/bash
. "/home/daniel/script/system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${DBMONITOR_PATH}/_srvList.${1}.sh"

LOG="${LOG_PATH}/chkIO.wrtn.${1}.${NDATE}.log";
ERROR_LOG="${LOG_PATH}/error_chkIO_wrtn.${1}.${NDATE}.log";
PROCESS_FILE="/tmp/chkIO_wrtn.pid";

### Check Process
_chkProcess "${PROCESS_FILE}";

### Return this script pid
echo $$ > ${PROCESS_FILE}

for dbwrtnIdx in "${!WRTNIO[@]}"
do
  dbip=${DBIP[$dbwrtnIdx]};
  dbhost=${DBHOST[$dbwrtnIdx]};
  dbwrtnio=${WRTNIO[$dbwrtnIdx]};

  if [ ${NHOUR} -ge "07" ] && [ ${NHOUR} -lt "20" ] ; then
        declare -i nowdbwrtnio=`/usr/bin/iostat -d -m 1 5|grep sda|awk '{print $4}'|sed '1,4d'|awk '{printf("%.f\n",$1)}'`;
        echo -e "${NDATETIME} ${dbhost} (${dbip}) Wrtn IO Is ${nowdbwrtnio} M." >> ${LOG};

     if [ "${nowdbwrtnio}" -gt "${dbwrtnio}" ]; then
        echo -e "${NDATETIME} ${dbhost} (${dbip}) Wrtn IO Is ${nowdbwrtnio} M. Over ${dbwrtnio} M !" >> ${ERROR_LOG};
        nowerrmsg="[ ${NDATETIME} ] ${dbhost} (${dbip}) Wrtn IO Is ${nowdbwrtnio} M";
        #printf "To: ${DBA_MAIL}\nFrom: ${DBA_MAIL}\nSubject: ${nowerrmsg}\n\nCritical Message\n" | /usr/sbin/ssmtp -t
        _sendErrorMESSAGE_slack "${dbhost}_Wrtn_IO_${nowdbwrtnio}_M_!";
     fi
  fi
done
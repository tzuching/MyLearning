#!/bin/bash
. "/home/daniel/script/system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${DBMONITOR_PATH}/_srvList.${1}.sh"

LOG="${LOG_PATH}/chkOsLog.${1}.${NDATE}.log";
ERROR_LOG="${LOG_PATH}/error_chkOsLog.${1}.${NDATE}.log";
PROCESS_FILE="/tmp/chkOsLog.pid";

### Check Process
_chkProcess "${PROCESS_FILE}";

### Return this script pid
echo $$ > ${PROCESS_FILE}

#---------------------------------------------------------------------
# Name: Check OS Message Log
# Desc_1 : Parse OS Error Message And Send SMS To DBA
# Desc_2 : Parse /var/log/messages Error Message
#---------------------------------------------------------------------

_ParseOsLog(){
  local _IP=$1;
  local _HOST=$2;
  local _MIN=$3;
  local _LOG=$4;
  if [ "$_LOG" == "" ]; then
    local _LOG="/var/log/messages";
  fi
  local _NDATE=`date +%Y%m%d`;
  local _DD=`date --date="${_MIN} minutes ago" "+%b %e %H:%M"`;
  #local _DD="Jul 23 20:14:51";
  #local _DD=`date --date="${MIN} day ago" "+%g%m%d 17:"`;
  #local _sshOption="StrictHostKeyChecking=no -o ConnectTimeout=1";

  mkdir -p /tmp/tmpOS
  local _str1="line=\`cat -n ${_LOG} |grep \"${_DD}\" |awk '{print \$1}' |head -1\`;";
  local _str2="sed -n \$line,\$\p ${_LOG} 2> /dev/null";
  #local _msg=`ssh -o ${_sshOption} mydba@${_IP} "${_str1}${_str2}"`;
  local _msg=`"${_str1}${_str2}"`;

  local _TMPFILE=`mktemp -p /tmp/tmpOS`;
  echo -e "${_msg}" > ${_TMPFILE};

  local _ERR="error|fail|NIC";
  local _parseMsg=`cat ${_TMPFILE}|egrep -i "${_ERR}"|egrep -v "cmdlog"`;
  if [ -n "${_parseMsg}" ]; then
    printf "%s(%s) %s have error.\n" ${_IP} ${_HOST} ${_LOG};
    _sendErrorMESSAGE "${_IP} (${_HOST}) ${_LOG} have error.";
  fi
  rm -rf ${_TMPFILE};
}

#---------------------------------------------------------------------

min=$1;
NDATE=`date +%Y%m%d`;

for ipIdx in "${!PHYIP[@]}"
do
  ip=${PHYIP[$ipIdx]};
  host=${PHYHOST[$ipIdx]};
  oslog=${PHYOSLOG[$ipIdx]};

  echo "host: ${host}(${ip})";
  _ParseOsLog "${ip}" "${host}" "${min}" "${oslog}";
done
#!/bin/bash

DBIP[0]="10.143.0.7";

DBHOST[0]="houston-app-awoo-org";

DBPORT[0]="80";

DBCPU[0]="90";

SPACE[0]="/";

SPACE_LIMIT[0]="90";

DBSWAP[0]="1000";

LOG[0]="/var/log/";

OSIP[0]="10.143.0.7";

READIO[0]="100";

WRTNIO[0]="100";

DBLIMIT[0]="104857600";

DBCOUNT[0]="30";

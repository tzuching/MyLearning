#!/bin/bash
. "/home/daniel/script/system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${DBMONITOR_PATH}/_srvList.${1}.sh"

LOG="${LOG_PATH}/chkSpace.${1}.${NDATE}.log";
ERROR_LOG="${LOG_PATH}/error_chkSpace.${1}.${NDATE}.log";
PROCESS_FILE="/tmp/chkSpace.pid";

### Check Process
_chkProcess "${PROCESS_FILE}";

### Return this script pid
echo $$ > ${PROCESS_FILE}

declare -i LIMIT=80;

for spaceIdx in "${!SPACE[@]}"
do
  space_limit=${LIMIT};
  dbip=${DBIP[$spaceIdx]};
  dbhost=${DBHOST[$spaceIdx]};
  space=${SPACE[$spaceIdx]};
  space_limit=${SPACE_LIMIT[$spaceIdx]};

  if [ "${space_limit}" = "" ]; then
    space_limit=${LIMIT};
  fi

  for s in `echo ${space}`
  do
    declare -i spaceSize=`df -h ${s} |tail -1|awk '{print $2}'|cut -d"G" -f1`
    declare -i spaceUsed=`df -h ${s} |tail -1|awk '{print $3}'|cut -d"G" -f1`
    declare -i spaceAvail=`df -h ${s} |tail -1|awk '{print $4}'|cut -d"G" -f1`
    declare -i spacePer=`df -h ${s} |tail -1|awk '{print $5}'|cut -d"%" -f1`
    #echo "${space_limit}";
       printf "%s (%s) Disk Space(%s) Avail %s%%.\n" ${dbip} ${dbhost} ${s} ${spacePer};
       echo -e "${NDATETIME} ${dbhost} (${dbip}) Diskspace(${s}) Is Size ${spaceSize}G | Used ${spaceUsed}G | Avail ${spaceAvail}G." >> ${LOG};
       echo -e "${NDATETIME} ${dbhost} (${dbip}) Diskspace(${s}) Is ${spacePer} Per." >> ${LOG};
       echo -e "----------------------------------------------------------------------------------------------------" >> ${LOG};
    if [ "${spacePer}" -gt "${space_limit}" ] ; then
       echo -e "${NDATETIME} ${dbhost} (${dbip}) Diskspace(${s}) Is Size ${spaceSize}G | Used ${spaceUsed}G | Avail ${spaceAvail}G." >> ${ERROR_LOG};
       echo -e "${NDATETIME} ${dbhost} (${dbip}) Diskspace(${s}) Is ${spacePer} Per , Over 90 Per !" >> ${ERROR_LOG};
       echo -e "----------------------------------------------------------------------------------------------------" >> ${ERROR_LOG};
       nowerrmsg="[ ${NDATETIME} ] ${dbhost} (${dbip}) Diskspace(${s}) Is ${spacePer} Per";
       #printf "To: ${DBA_MAIL}\nFrom: ${DBA_MAIL}\nSubject: ${nowerrmsg}\n\nCritical Message\n" | /usr/sbin/ssmtp -t
       _sendErrorMESSAGE_slack "${dbhost}_Diskspace(${s})_Is_${spacePer}_Per_!";
    fi
  done
done

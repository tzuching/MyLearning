#!/bin/bash
. "/home/daniel/script/system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${DBMONITOR_PATH}/_srvList.${1}.sh"

PROCESS_FILE="/tmp/_monitor_thirty.pid";
FAIL=0;
SERVER_NAME='houstonapp';

### Check Process
_chkProcess "${PROCESS_FILE}";

### Return this script pid
echo $$ > ${PROCESS_FILE}

### Check Server Script
sleep 1 && /usr/bin/sudo /home/daniel/script/monitor/04_chkSpace.sh ${SERVER_NAME} > /dev/null 2>&1 && true &
sleep 1 && /usr/bin/sudo /home/daniel/script/monitor/05_chkSwap.sh ${SERVER_NAME} > /dev/null 2>&1 && true &

### Del_Old_Sessions
find /run/systemd/sessions -type f -atime +3 -print -exec rm -f '{}' \;

### Wait
for job in `jobs -p`
do
  echo "Wait job: ${job}"
  wait $job || let FAIL+=1
done

### Check
if [ $FAIL -eq 0 ]; then
  echo "All jobs are done."
else
  echo "${FAIL} jobs fail!"
fi

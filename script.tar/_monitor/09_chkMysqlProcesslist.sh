#!/bin/bash
. "/home/daniel/script/system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${DBMONITOR_PATH}/_srvList.${1}.sh"

LOG="${LOG_PATH}/chkProcesslist.${1}.${NDATE}.log";
ERROR_LOG="${LOG_PATH}/error_chkProcesslist.${1}.${NDATE}.log";
PROCESS_FILE="/tmp/chkProcesslist.pid";
DBUSER="dba_monitor";
DBPASSWD="D7EZvvcck3te6qH4MqhCam25DdaXDbMB";
DBHOSTIP="houston01.awoo.org";
DBHOSTNAME="houston_Mysql";
QUERYLIMIT="5";

# ====================================================================================================

#CHECK_LIST=`mysql -u${DBUSER} -p${DBPASSWD} -e "SELECT TIME FROM INFORMATION_SCHEMA.PROCESSLIST"| wc -l | awk 'NR==2{printf $1}'`;
#SQL_1="INSERT INTO processlist (DAY,TIME,HOST,LIST)";
#SQL_2="${SQL_1} VALUES ('"${MYSQLDAY}"','"${MYSQLTIME}"','"${HOST}"',${CHECK_LIST});";
#INSSQL="/tmp/processlist_insert.${FILETIME}.sql";
#/usr/bin/echo ${MYSQLDB}${SQL_2} >> ${INSSQL}
#/usr/bin/scp -r ${INSSQL} ${SSHUSER}@${SSHIP}://tmp
#${SSHOPTION} ${SSHUSER}@${SSHIP} "${MYSQLCMD} -v -u${MYSQLUSER} -p${MYSQLPASS} < ${INSSQL}";
#${SSHOPTION} ${SSHUSER}@${SSHIP} "rm -rf ${INSSQL}";${SSHOPTION} ${SSHUSER}@${SSHIP} "rm -rf ${INSSQL}";
#/usr/bin/rm -rf ${INSSQL}

# ====================================================================================================

### Check Process
_chkProcess "${PROCESS_FILE}";

### Return this script pid
echo $$ > ${PROCESS_FILE}

for dbiplidx in "${!DBIP[@]}"
do
  dbip=${DBIP[$dbiplidx]};
  dbhost=${DBHOST[$dbiplidx]};

  if [ ${NHOUR} -ge "06" ] && [ ${NHOUR} -lt "20" ] ; then

      PROCESSLIST_COUNTALL=`mysql -u${DBUSER} -p${DBPASSWD} -h${DBHOSTIP} -e "USE INFORMATION_SCHEMA;SELECT COUNT(ID) FROM INFORMATION_SCHEMA.PROCESSLIST;"| awk 'NR==2{printf $1}'`;
      PROCESSLIST_CHECK=`mysql -u${DBUSER} -p${DBPASSWD} -h${DBHOSTIP} -e "USE INFORMATION_SCHEMA;SELECT TIME FROM INFORMATION_SCHEMA.PROCESSLIST WHERE COMMAND = 'Query' AND TIME > 3 ORDER BY TIME DESC LIMIT 1;"| awk 'NR==2{printf $1}'`;
      PROCESSLIST_CHECK_QUERY=`mysql -u${DBUSER} -p${DBPASSWD} -h${DBHOSTIP} -e "USE INFORMATION_SCHEMA;SELECT TIME,USER,HOST,DB,COMMAND,INFO FROM INFORMATION_SCHEMA.PROCESSLIST WHERE COMMAND = 'Query' AND TIME > 3 ORDER BY TIME DESC;"`;
      NETSTAT_CHECK=`netstat -an | grep :80 | grep -v tcp6 | grep -v :8080  | sort|wc -l`;

     if [[ -z "${PROCESSLIST_CHECK}" ]]; then
                echo -e "[ ${NDATETIME} ] ${dbhost} Processlist Count is ( ${PROCESSLIST_COUNTALL} )." >> ${LOG};
                echo -e "[ ${NDATETIME} ] ${dbhost} Netstat Weblist Count is ( ${NETSTAT_CHECK} )." >> ${LOG};
                echo -e "[ ${NDATETIME} ] ${dbhost} (${DBHOSTNAME}) SQL Query Is Good." >> ${LOG};
		echo -e "----------------------------------------------------------------------------------------------------" >> ${LOG};
        else

         if [ "${PROCESSLIST_CHECK}" -gt "${QUERYLIMIT}" ]; then
                echo -e "[ ${NDATETIME} ] ${dbhost} Processlist Count is ( ${PROCESSLIST_COUNTALL} )." >> ${ERROR_LOG};
                echo -e "[ ${NDATETIME} ] ${dbhost} Netstat Weblist Count is ( ${NETSTAT_CHECK} )." >> ${ERROR_LOG};
                echo -e "[ ${NDATETIME} ] ${dbhost} (${DBHOSTNAME}) SQL Query Is Overfull ${PROCESSLIST_CHECK} Sec !" >> ${ERROR_LOG};
                echo -e "${PROCESSLIST_CHECK_QUERY}" >> ${ERROR_LOG};
		echo -e "----------------------------------------------------------------------------------------------------" >> ${ERROR_LOG};                
                nowerrmsg="[ ${NDATETIME} ] ${dbhost} (${DBHOSTNAME}) SQL Query Is Overfull ${PROCESSLIST_CHECK} Sec.";
                printf "To: ${DBA_MAIL}\nFrom: ${DBA_MAIL}\nSubject: ${nowerrmsg}\n\nCritical Message\n" | /usr/sbin/ssmtp -t
                _sendErrorMESSAGE_slack "${DBHOSTNAME}_SQL_Query_Is_Overfull_${PROCESSLIST_CHECK}_Sec_!";
         fi
     fi
  fi
done

#!/bin/bash
. "/home/daniel/script/system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${DBMONITOR_PATH}/_srvList.${1}.sh"

LOG="${LOG_PATH}/chkSwap.${1}.${NDATE}.log";
ERROR_LOG="${LOG_PATH}/error_chkSwap.${1}.${NDATE}.log";
PROCESS_FILE="/tmp/chkSwap.pid";

### Check Process
_chkProcess "${PROCESS_FILE}";

### Return this script pid
echo $$ > ${PROCESS_FILE}

for dbswapIdx in "${!DBSWAP[@]}"
do
  dbip=${DBIP[$dbswapIdx]};
  dbhost=${DBHOST[$dbswapIdx]};
  dbswap=${DBSWAP[$dbswapIdx]};

  if [ ${NHOUR} -ge "07" ] && [ ${NHOUR} -lt "20" ] ; then
        declare -i nowmemtotal=`free -m |grep Mem|awk '{print $2}'`;
        declare -i nowmemused=`free -m |grep Mem|awk '{print $3}'`;
        declare -i nowmemfree=`free -m |grep Mem|awk '{print $4}'`;
        declare -i nowswap=`free -m |grep Swap|awk '{print $3}'`;
        echo -e "${NDATETIME} ${dbhost} (${dbip}) Use Memory Is Total ${nowmemtotal} M | Used ${nowmemused} M | Free ${nowmemfree} M." >> ${LOG};
        echo -e "${NDATETIME} ${dbhost} (${dbip}) Use Swap Is ${nowswap} M." >> ${LOG};
	echo -e "----------------------------------------------------------------------------------------------------" >> ${LOG};        
        #nowmsg="[ ${NDATETIME} ] ${dbhost} (${dbip}) use swap is ${nowswap} M";
        #echo "[ ${NDATETIME} ] ${dbhost} (${dbip}) use swap is ${nowswap} M" | /usr/sbin/ssmtp ${DBA_MAIL};
        #printf "To: ${DBA_MAIL}\nFrom: ${DBA_MAIL}\nSubject: ${nowmsg}\n\nCritical Message\n" | ssmtp -t

     if [ "${nowswap}" -gt "${dbswap}" ]; then
        echo -e "${NDATETIME} ${dbhost} (${dbip}) Use Memory Is Total ${nowmemtotal} M | Used ${nowmemused} M | Free ${nowmemfree} M." >> ${ERROR_LOG};
        echo -e "${NDATETIME} ${dbhost} (${dbip}) Swap Is ${nowswap} M. Over ${dbswap} M !" >> ${ERROR_LOG};
	echo -e "----------------------------------------------------------------------------------------------------" >> ${ERROR_LOG};        
        nowerrmsg="[ ${NDATETIME} ] ${dbhost} (${dbip}) Swap Is ${nowswap} M";
        #printf "To: ${DBA_MAIL}\nFrom: ${DBA_MAIL}\nSubject: ${nowerrmsg}\n\nCritical Message\n" | /usr/sbin/ssmtp -t
        _sendErrorMESSAGE_slack "${dbhost}_Use_Swap_${nowswap}_M_!";
     fi
  fi
done

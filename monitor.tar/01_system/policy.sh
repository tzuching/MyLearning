#!/bin/bash

ssh_allow_ip="
123.204.141.11
127.0.0.1
"

# clear policy
/sbin/iptables -F

# allow
for ip in ${ssh_allow_ip}
do
  iptables -I INPUT -s ${ip} -p tcp --dport 20010 -j ACCEPT
done

# deny
iptables -A INPUT -p TCP --dport 20010 -j LOG --log-prefix "*Drop mongo*"
iptables -A INPUT -p UDP --dport 20010 -j LOG --log-prefix "*Drop mongo*"
iptables -A INPUT -p TCP --dport 20010 -j DROP
iptables -A INPUT -p UDP --dport 20010 -j DROP

# show policy
echo "policy Info"
echo "==========="
iptables -L -n
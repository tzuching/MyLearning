#!/bin/bash
############################################################
HOST=`hostname -s`;
############################################################
DBA_MAIL="tzuching@awoo.com.tw";
############################################################
SSHOPTION="StrictHostKeyChecking=no -o ConnectTimeout=1";
NMINS=`date +"%M"`;
NHOUR=`date +"%H"`;
NDATE=`date +"%Y%m%d"`;
NDATETIME=`date +"%Y-%m-%d %H:%M:%S"`;
############################################################
LOG_PATH="/home/daniel/monitor/00_log";
INCLUDE_PATH="/home/daniel/monitor/01_system";
MONGODB_PATH="/home/daniel/monitor/02_mongodb";
SLACK_LOG="${LOG_PATH}/message.slack.${NDATE}.log";
touch ${SLACK_LOG}
chmod 700 ${SLACK_LOG}
############################################################
ERRGREP1[0]="[rsHealthPoll]";
ERRGREP2[0]="down|heartbeat failed|pthread_create failed";
#ERRGREP2[0]="conn125";
#ERRGREP1[1]="[WriteBackListener";
#ERRGREP2[1]="9001 socket exception|110 Connection timed out";
############################################################
find ${LOG_PATH}/*.log -mtime +90 -exec rm -rf {} \;
find ${LOG_PATH}/*.log -empty -exec rm -rf {} \;
############################################################
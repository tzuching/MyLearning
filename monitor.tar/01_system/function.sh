#!/bin/bash

#==========================================================================================
#  Name: sendError MESSAGE_slack
#  Desc: send message to slack [ $1 -> message to send ]
#==========================================================================================

_sendErrorMESSAGE_slack()
{
  local _DATE=`date +"%Y%m%d"`;
  local _DATETIME=`date +"%Y-%m-%d_%H:%M"`;
  local _HOSTNAME=`hostname -s`;
  local _STRMSG="${1}_From_${HOSTNAME}_${_DATETIME}";
  local _CHANNEL="#dba-monitor";
  local _USERNAME="awoo-monitor-robot";
  local _LOG="/home/daniel/monitor/00_log/message.slack.${_DATE}.log";

  if [ $# -lt 1 ] ; then
    _printERROR "Please give a message to send.";
    return 1
  fi

  _SLACK[0]="https://hooks.slack.com/services/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";

  for _slack in "${_SLACK[@]}"
  do
    echo -e "[ ${_DATETIME} ]  ${_STRMSG}" >> ${_LOG};
    curl -X POST --data-urlencode 'payload={"channel": "'${_CHANNEL}'", "username": "'${_USERNAME}'", "text": "'${_STRMSG}'", "icon_emoji": ":robot_face:"}' ${_slack}
  done
}

#==========================================================================================
#  Name: Check Process
#  Desc: Return this script pid
#==========================================================================================

_chkProcess()
{
  local _PIDFILE="${1}";
  #echo ${_PIDFILE}
  local _aa=$(cat `ls ${_PIDFILE} 2>&1` |awk '{str=str"|"$1} END {print ""substr(str,2)""}');
  #echo ${_aa}
  if [ "${_aa}" != "" ];then
    #echo ${_aa}
    local _process=$(ps -ef |awk "{if(\$2==${_aa}) print \$2}");
  fi;
  #echo "${_process}"
  if [ "${_process}" != "" ];then
    #echo "exit func";
    exit;
  fi
}

#==========================================================================================
#  Name:
#  Desc:
#==========================================================================================

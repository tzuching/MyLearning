##################################################
# Script Name :  Mongodb Script
# Maintainer  :  Daniel Tsai
# Updated     :  2017-07
##################################################
#!/bin/bash
#####
echo " "
echo "執行 [  設定 MongoDB 各參數及資料夾位置  ] ( #如輸入錯誤請按 Ctrl + C 即可離開 )"
echo " "
##########
read -p "Continue ? [請再次確認是否要繼續執行] ( 1 = 繼續 or 0 = 離開 ) : " GO_CONTINUE_ONE
### Continue
sleep 1
if [ $GO_CONTINUE_ONE -eq 0 ]; then
    echo " "
    echo "Bye! Bye!"
    echo " "
    exit
else
    echo " "
    echo "Go! Continue!"
    echo " "
fi
##########
echo " "
echo "您選擇繼續執行 - [ 開始設定 Mongodb 環境 ] !"
echo " "
##################################################
echo " "
read -p "Please Insert -> 請輸入第一台 MongoDB 主機 IP : " MONGODB_IP_ONE
echo " "
read -p "Please Insert -> 請輸入第二台 MongoDB 主機 IP : " MONGODB_IP_TWO
echo " "
read -p "Please Insert -> 請輸入第三台 MongoDB 主機 IP : " MONGODB_IP_THREE
echo " "
##########
read -p "Continue ? [請再次確認是否要繼續執行] ( 1 = 繼續 or 0 = 離開 ) : " GO_CONTINUE_TWO
### Continue
sleep 1
if [ $GO_CONTINUE_TWO -eq 0 ]; then
    echo " "
    echo "Bye! Bye!"
    echo " "
    exit
else
    echo " "
    echo "Go! Continue!"
    echo " "
fi
##################################################
### yum update
sleep 1
echo " ">> /etc/hosts
echo "####################">> /etc/hosts
echo " ">> /etc/hosts
echo "# mongo config server -- earth">> /etc/hosts
echo "$MONGODB_IP_ONE     awoo-earth-cfg1.104.com.tw awoo-earth-cfg1">> /etc/hosts
echo "$MONGODB_IP_TWO     awoo-earth-cfg2.104.com.tw awoo-earth-cfg2">> /etc/hosts
echo "$MONGODB_IP_THREE     awoo-earth-cfg3.104.com.tw awoo-earth-cfg3">> /etc/hosts
echo " ">> /etc/hosts
echo "# mongod arb -- earth">> /etc/hosts
echo "$MONGODB_IP_ONE     awoo-earth-arb1.104.com.tw awoo-earth-arb1">> /etc/hosts
echo "$MONGODB_IP_TWO     awoo-earth-arb2.104.com.tw awoo-earth-arb2">> /etc/hosts
echo "$MONGODB_IP_THREE     awoo-earth-arb3.104.com.tw awoo-earth-arb3">> /etc/hosts
echo " ">> /etc/hosts
echo "# mongod -- earth">> /etc/hosts
echo "$MONGODB_IP_ONE     awoo-earth-01.104.com.tw awoo-earth-01">> /etc/hosts
echo "$MONGODB_IP_TWO     awoo-earth-02.104.com.tw awoo-earth-02">> /etc/hosts
echo "$MONGODB_IP_THREE     awoo-earth-03.104.com.tw awoo-earth-03">> /etc/hosts
echo " ">> /etc/hosts
echo "$MONGODB_IP_ONE     awoo-earth-01-01">> /etc/hosts
echo "$MONGODB_IP_TWO     awoo-earth-01-02">> /etc/hosts
echo "$MONGODB_IP_THREE     awoo-earth-01-03">> /etc/hosts
echo " ">> /etc/hosts
echo "# mongo S -- earth">> /etc/hosts
echo "$MONGODB_IP_ONE     awoo-earth-s1.104.com.tw awoo-earth-s1">> /etc/hosts
echo "$MONGODB_IP_TWO     awoo-earth-s2.104.com.tw awoo-earth-s2">> /etc/hosts
echo "$MONGODB_IP_THREE     awoo-earth-s3.104.com.tw awoo-earth-s3">> /etc/hosts
echo " ">> /etc/hosts
echo "####################">> /etc/hosts
sleep 1
cat /etc/hosts
sleep 3
##########
echo " "
echo "主機 hosts 變更完成 !"
echo " "
##################################################
## 相關 Folder
chown -R root:dba /awoo
chmod -R o-rwx /awoo
chmod -R ug+rwx /awoo
##########
## mdb Folder
mkdir -p /var/lib/mongo/mdb/
chown -R mongodb:dba /var/lib/mongo/mdb/
## mongod server
mkdir -p /var/lib/mongo/mdb/node/
mkdir -p /var/lib/mongo/mdb/node/01/data
mkdir -p /var/lib/mongo/mdb/node/log
echo "awooearth" > /var/lib/mongo/mdb/node/mongoKey
chown -R mongodb:dba /var/lib/mongo/mdb
chmod 700 /var/lib/mongo/mdb/node/mongoKey
chown -R mongodb:dba /var/lib/mongo/mdb/*
sleep 1
##################################################
read -p "* 請選擇設定檔參數是在那一台主機上 [請再次確認是否要繼續執行] ( 1 = 第一台 or 2 = 第二台 or 3 = 第三台 ) : " GO_DB_INSTALL
### Continue
if [ $GO_DB_INSTALL = "1" ]
then
    echo "您選擇設定 [ 第一台 ]"
				##################################################
				sleep 1
				## arb1 server node
				mkdir -p /var/lib/mongo/mdb/arb1/01/data
				mkdir -p /var/lib/mongo/mdb/arb1/log
				echo "awooearth" > /var/lib/mongo/mdb/arb1/mongoKey
				chown -R mongodb:dba /var/lib/mongo/mdb/arb1/
				chmod 700 /var/lib/mongo/mdb/arb1/mongoKey
				## cfg1 server node
				mkdir -p /var/lib/mongo/mdb/cfg1/configdb
				mkdir -p /var/lib/mongo/mdb/cfg1/log
				echo "awooearth" > /var/lib/mongo/mdb/cfg1/mongoKey
				chown -R mongodb:dba /var/lib/mongo/mdb/cfg1
				chmod 700 /var/lib/mongo/mdb/cfg1/mongoKey
				chown -R mongodb:dba /var/lib/mongo/mdb/cfg1/configdb
				chown -R mongodb:dba /var/lib/mongo/mdb/cfg1/log
				## s1 server node
				mkdir /var/lib/mongo/mdb/mongos/
				mkdir /var/lib/mongo/mdb/mongos/log/
				echo "awooearth" > /var/lib/mongo/mdb/mongos/mongoKey
				chown -R mongodb:dba /var/lib/mongo/mdb/mongos/
				chmod 700 /var/lib/mongo/mdb/mongos/mongoKey				
				sleep 1
				echo "第一台設定完成 [ End ]"
				sleep 1
				/bin/tree -afgCp /var/lib/mongo/mdb/
				sleep 3				
				##################################################
elif [ $GO_DB_INSTALL = "2" ]
then
    echo "您選擇設定 [ 第二台 ]"
				##################################################	
				sleep 1
				## arb2 server node
				mkdir -p /var/lib/mongo/mdb/arb2/01/data
				mkdir -p /var/lib/mongo/mdb/arb2/log
				echo "awooearth" > /var/lib/mongo/mdb/arb2/mongoKey
				chown -R mongodb:dba /var/lib/mongo/mdb/arb2/
				chmod 700 /var/lib/mongo/mdb/arb2/mongoKey
				## cfg2 server node
				mkdir -p /var/lib/mongo/mdb/cfg2/configdb
				mkdir -p /var/lib/mongo/mdb/cfg2/log
				echo "awooearth" > /var/lib/mongo/mdb/cfg2/mongoKey
				chown -R mongodb:dba /var/lib/mongo/mdb/cfg2
				chmod 700 /var/lib/mongo/mdb/cfg2/mongoKey
				chown -R mongodb:dba /var/lib/mongo/mdb/cfg2/configdb
				chown -R mongodb:dba /var/lib/mongo/mdb/cfg2/log
				## s2 server node
				mkdir /var/lib/mongo/mdb/mongos/
				mkdir /var/lib/mongo/mdb/mongos/log/
				echo "awooearth" > /var/lib/mongo/mdb/mongos/mongoKey
				chown -R mongodb:dba /var/lib/mongo/mdb/mongos/
				chmod 700 /var/lib/mongo/mdb/mongos/mongoKey
				sleep 1
				echo "第二台設定完成 [ End ]"
				sleep 1
				/bin/tree -afgCp /var/lib/mongo/mdb/
				sleep 3				
				##################################################
    exit 0
##########	
elif [ $GO_DB_INSTALL = "3" ]
then
    echo "您選擇設定 [ 第三台 ]"
				##################################################
				sleep 1
				## arb3 server node
				mkdir -p /var/lib/mongo/mdb/arb3/01/data
				mkdir -p /var/lib/mongo/mdb/arb3/log
				echo "awooearth" > /var/lib/mongo/mdb/arb3/mongoKey
				chown -R mongodb:dba /var/lib/mongo/mdb/arb3/
				chmod 700 /var/lib/mongo/mdb/arb3/mongoKey
				## cfg3 server node
				mkdir -p /var/lib/mongo/mdb/cfg3/configdb
				mkdir -p /var/lib/mongo/mdb/cfg3/log
				echo "awooearth" > /var/lib/mongo/mdb/cfg3/mongoKey
				chown -R mongodb:dba /var/lib/mongo/mdb/cfg3
				chmod 700 /var/lib/mongo/mdb/cfg3/mongoKey
				chown -R mongodb:dba /var/lib/mongo/mdb/cfg3/configdb
				chown -R mongodb:dba /var/lib/mongo/mdb/cfg3/log
				## s3 server node
				mkdir /var/lib/mongo/mdb/mongos/
				mkdir /var/lib/mongo/mdb/mongos/log/
				echo "awooearth" > /var/lib/mongo/mdb/mongos/mongoKey
				chown -R mongodb:dba /var/lib/mongo/mdb/mongos/
				chmod 700 /var/lib/mongo/mdb/mongos/mongoKey
				sleep 1
				echo "第三台設定完成 [ End ]"
				sleep 1
				/bin/tree -afgCp /var/lib/mongo/mdb/
				sleep 3				
				##################################################
	echo "全部執行完畢 [ End ]"
    exit 0
else
    echo "Please try again from given options only."
fi
##########				
echo " "
echo "執行完畢 [ End ]"
echo " "
echo "後續透過 sh 啟動服務後請記得 ↓"
echo " "
echo "1. 設定 Data node replset define 參數"
echo "2. 設定 Config replset define 參數"
echo "3. 建立 Admin User 帳號"
echo "4. 設定 Shard lists"
echo "5. 使用 User 匯入資料測試"
echo " "
echo "Bye! Bye!"
echo " "
##################################################
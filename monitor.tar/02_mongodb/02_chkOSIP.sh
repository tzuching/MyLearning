#!/bin/bash
. "/home/daniel/monitor/01_system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${MONGODB_PATH}/_srvList.${1}.sh"

LOG="${LOG_PATH}/chkOSIP.${1}.${NDATE}.log";
ERROR_LOG="${LOG_PATH}/error_chkOSIP.${1}.${NDATE}.log";
PROCESS_FILE="/tmp/chkOSIP.pid";

### Check Process
_chkProcess "${PROCESS_FILE}";

### Return this script pid
echo $$ > ${PROCESS_FILE}

for osipIdx in "${!OSIP[@]}"
do
  declare -i failCount=0;
  osip=${OSIP[$osipIdx]};
  dbhost=${DBHOST[$osipIdx]};
  dbip=${DBIP[$osipIdx]};

  for (( i=1; i<=3; i=i+1 ))
  do
    NTIME=`date +"%Y-%m-%d %H:%M:%S"`;
    declare osipCount=`/sbin/ip addr list|grep -c "${osip}"`
    echo -e "${NTIME} ${dbhost} Binding IP is OK ( status ${osipCount} )" >> ${LOG};

    if [ $osipCount -eq "0" ] ; then
       failCount=failCount+1;
    fi
    sleep 3;
  done

  if [ $failCount -eq "3" ] ; then
    echo -e "${NTIME} ${dbhost} Not Binding IP ${osip} !" >> ${LOG};
    nowerrmsg="[ ${NTIME} ] ${dbhost} Not Binding IP ${osip}";
    printf "To: ${DBA_MAIL}\nFrom: ${DBA_MAIL}\nSubject: ${nowerrmsg}\n\nCritical Message\n" | /usr/sbin/ssmtp -t
    _sendErrorMESSAGE_slack "${dbhost}_(${dbip})_not_binding_ip_${osip}_!";
  fi
done
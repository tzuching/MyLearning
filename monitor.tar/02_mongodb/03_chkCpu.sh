#!/bin/bash
. "/home/daniel/monitor/01_system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${MONGODB_PATH}/_srvList.${1}.sh"

LOG="${LOG_PATH}/chkCpu.${1}.${NDATE}.log";
ERROR_LOG="${LOG_PATH}/error_chkCpu.${1}.${NDATE}.log";
PROCESS_FILE="/tmp/chkCpu.pid";

### Check Process
_chkProcess "${PROCESS_FILE}";

### Return this script pid
echo $$ > ${PROCESS_FILE}

for dbcpuIdx in "${!DBCPU[@]}"
do
  dbip=${DBIP[$dbcpuIdx]};
  dbhost=${DBHOST[$dbcpuIdx]};
  dbcpu=${DBCPU[$dbcpuIdx]};

  if [ $NHOUR -ge "00" ] && [ $NHOUR -lt "24" ] ; then
        #declare -i nowcpu=`${MONGODB_PATH}/check_cpu_usage -H ${dbip} -C dba -n i|awk '{print $5}' |awk -F % '{print $1}'`
        #echo "Please check your processess on ${HOSTNAME} the value of cpu load is $CPU_LOAD % & $PROC" > $MAILFILE
        #declare -i procid=`ps -eo pcpu -o comm= | sort -k1 -n -r | head -1`
        declare -i nowcpu=`sar -P ALL 1 2 |grep 'Average.*all' |awk -F" " '{print 100.0 -$NF}' |awk '{printf("%.f\n",$1)}'`;
        echo -e "${NDATETIME} ${dbhost} (${dbip}) cpu is ${nowcpu} per." >> ${LOG};
     if [ "$nowcpu" -gt "${dbcpu}" ]; then
        echo -e "${NDATETIME} ${dbhost} (${dbip}) cpu is ${nowcpu} per. over ${dbcpu} per !" >> ${ERROR_LOG};
        nowerrmsg="[ ${NDATETIME} ] ${dbhost} (${dbip}) cpu is ${nowcpu} per";
        printf "To: ${DBA_MAIL}\nFrom: ${DBA_MAIL}\nSubject: ${nowerrmsg}\n\nCritical Message\n" | /usr/sbin/ssmtp -t
        _sendErrorMESSAGE_slack "${dbhost}_cpu_${nowcpu}_over_${dbcpu}_!";
     fi
  fi
done
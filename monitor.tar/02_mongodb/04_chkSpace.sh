#!/bin/bash
. "/home/daniel/monitor/01_system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${MONGODB_PATH}/_srvList.${1}.sh"

LOG="${LOG_PATH}/chkSpace.${1}.${NDATE}.log";
ERROR_LOG="${LOG_PATH}/error_chkSpace.${1}.${NDATE}.log";
PROCESS_FILE="/tmp/chkSpace.pid";

### Check Process
_chkProcess "${PROCESS_FILE}";

### Return this script pid
echo $$ > ${PROCESS_FILE}

declare -i LIMIT=80;

for spaceIdx in "${!SPACE[@]}"
do
  space_limit=${LIMIT};
  dbip=${DBIP[$spaceIdx]};
  dbhost=${DBHOST[$spaceIdx]};
  space=${SPACE[$spaceIdx]};
  space_limit=${SPACE_LIMIT[$spaceIdx]};

  if [ "${space_limit}" = "" ]; then
    space_limit=${LIMIT};
  fi

  for s in `echo ${space}`
  do
    declare -i spacePer=`df -h ${s} |tail -1|awk '{print $5}'|cut -d"%" -f1`
    #echo "${space_limit}";
       printf "%s (%s) Disk Space(%s) Avail %s%%.\n" ${dbip} ${dbhost} ${s} ${spacePer};
       echo -e "${NDATETIME} ${dbhost} (${dbip}) diskspace(${s}) is ${spacePer} per." >> ${LOG};
    if [ "$spacePer" -gt "${space_limit}" ] ; then
       echo -e "${NDATETIME} ${dbhost} (${dbip}) diskspace(${s}) is ${spacePer} per , over 80 per !" >> ${ERROR_LOG};
       nowerrmsg="[ ${NDATETIME} ] ${dbhost} (${dbip}) diskspace(${s}) is ${spacePer} per";
       printf "To: ${DBA_MAIL}\nFrom: ${DBA_MAIL}\nSubject: ${nowerrmsg}\n\nCritical Message\n" | /usr/sbin/ssmtp -t
       _sendErrorMESSAGE_slack "${dbhost}_diskspace(${s})_is_${spacePer}_per_!";
    fi
  done
done
#!/bin/bash

DBIP[0]="139.162.80.197";

DBHOST[0]="earth-mongodb";

DBPORT[0]="27017";

DBCPU[0]="70";

SPACE[0]="/";

SPACE_LIMIT[0]="90";

DBSWAP[0]="1500";

LOG[0]="/var/log/mongodb/mongod.log";

OSIP[0]="139.162.80.197";

READIO[0]="10";

WRTNIO[0]="10";
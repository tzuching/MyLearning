#!/bin/bash
. "/home/daniel/monitor/01_system/config.sh"
. "${INCLUDE_PATH}/function.sh"
. "${MONGODB_PATH}/_srvList.${1}.sh"

LOG="${LOG_PATH}/chkIO.read.${1}.${NDATE}.log";
ERROR_LOG="${LOG_PATH}/error_chkIO_read.${1}.${NDATE}.log";
PROCESS_FILE="/tmp/chkIO_read.pid";

### Check Process
_chkProcess "${PROCESS_FILE}";

### Return this script pid
echo $$ > ${PROCESS_FILE}

for dbreadIdx in "${!READIO[@]}"
do
  dbip=${DBIP[$dbreadIdx]};
  dbhost=${DBHOST[$dbreadIdx]};
  dbreadio=${READIO[$dbreadIdx]};

  if [ $NHOUR -ge "00" ] && [ $NHOUR -lt "24" ] ; then
        declare -i nowdbreadio=`/usr/bin/iostat -d -m 1 5|grep sda|awk '{print $3}'|sed '1,4d'|awk '{printf("%.f\n",$1)}'`;
        echo -e "${NDATETIME} ${dbhost} (${dbip}) Read IO is ${nowdbreadio} M." >> ${LOG};

     if [ "$nowdbreadio" -gt "${dbreadio}" ]; then
        echo -e "${NDATETIME} ${dbhost} (${dbip}) Read IO is ${nowdbreadio} M. over ${dbreadio} M !" >> ${ERROR_LOG};
        nowerrmsg="[ ${NDATETIME} ] ${dbhost} (${dbip}) Read IO is ${nowdbreadio} M";
        printf "To: ${DBA_MAIL}\nFrom: ${DBA_MAIL}\nSubject: ${nowerrmsg}\n\nCritical Message\n" | /usr/sbin/ssmtp -t
        _sendErrorMESSAGE_slack "${dbhost}_Read_IO_${nowdbreadio}_M_!";
     fi
  fi
done